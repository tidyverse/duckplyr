test_that("new_relational()", {
  expect_snapshot({
    new_relational(list())
  })
})
