# compute()

    Code
      duckdb_rel_from_df(out)
    Message
      DuckDB Relation: 
      ---------------------
      --- Relation Tree ---
      ---------------------
      Scan Table [duckplyr_4hYuvhNS26]
      
      ---------------------
      -- Result Columns  --
      ---------------------
      - x (DOUBLE)
      

