# methods_overwrite() works

    Code
      methods_overwrite()
    Message
      v Overwriting dplyr methods with duckplyr methods.
      i Turn off with `duckplyr::methods_restore()`.

---

    Code
      methods_restore()
    Message
      i Restoring dplyr methods.

